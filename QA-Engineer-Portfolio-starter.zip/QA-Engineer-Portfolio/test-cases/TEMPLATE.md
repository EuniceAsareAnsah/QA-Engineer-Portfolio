# Test Cases: [Feature name]

> Use public demo sites only (for example saucedemo.com or demoqa.com). Never publish client, employer or NDA material here.

| ID | Title | Preconditions | Steps | Expected result | Priority | Status |
|---|---|---|---|---|---|---|
| TC-001 | | | | | | Not run |
| TC-002 | | | | | | Not run |
