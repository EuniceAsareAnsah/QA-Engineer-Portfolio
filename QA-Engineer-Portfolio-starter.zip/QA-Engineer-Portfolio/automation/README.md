# Automation

Work in progress. I'm building automated tests on public demo sites and adding them here as each one works.

> Use public demo sites only (for example saucedemo.com or demoqa.com). Never publish client, employer or NDA material here.

## Planned

- [ ] UI test suite (Playwright or Cypress with TypeScript)
- [ ] API checks (Postman collection run with Newman)
- [ ] GitHub Actions workflow that runs the tests on every push
- [ ] One simple performance test (k6 or JMeter)
- [ ] PowerShell / Bash helper scripts
