# Exploratory Session: [Charter]

> Use public demo sites only (for example saucedemo.com or demoqa.com). Never publish client, employer or NDA material here.

- **Charter:** Explore [area] with [resources] to discover [information]
- **Date / duration:**
- **Tester:** Eunice Ansah Asare

## Notes

## Bugs Found

## Questions and Risks

## Next Session Ideas
