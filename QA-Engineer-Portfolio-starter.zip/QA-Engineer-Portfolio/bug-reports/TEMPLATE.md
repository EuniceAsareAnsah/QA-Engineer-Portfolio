# Bug Report: [Short, specific title]

> Use public demo sites only (for example saucedemo.com or demoqa.com). Never publish client, employer or NDA material here.

| Field | Detail |
|---|---|
| Application / URL | |
| Environment | Browser / device / OS / version |
| Severity | Critical / High / Medium / Low |
| Priority | |
| Date found | |

## Steps to Reproduce
1.
2.
3.

## Expected Result

## Actual Result

## Evidence
Screenshot or screen recording link.

## Notes
Frequency, workaround, related issues, console or network errors.
